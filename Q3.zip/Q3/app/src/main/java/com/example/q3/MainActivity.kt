package com.example.q3


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MusicPlayerScreen()
        }
    }
}

@Composable
fun MusicPlayerScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Album cover centered at the top
        Image(
            painter = painterResource(id = R.drawable.album_cover), // hard-coded album cover
            contentDescription = "Album Cover",
            modifier = Modifier
                .size(300.dp)
                .align(Alignment.TopCenter)
        )

        // Song title and artist name below album cover
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(top = 320.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Song Title")
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Artist Name")
        }

        // Playback controls at the bottom
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Previous button (using an image as an icon)
            Button(onClick = { /* no action for static screen */ }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_skip_previous),
                    contentDescription = "Previous"
                )
            }
            // Play button
            Button(onClick = { /* no action for static screen */ }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_play),
                    contentDescription = "Play"
                )
            }
            // Pause button
            Button(onClick = { /* no action for static screen */ }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_pause),
                    contentDescription = "Pause"
                )
            }
            // Next button
            Button(onClick = { /* no action for static screen */ }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_skip_next),
                    contentDescription = "Next"
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MusicPlayerScreenPreview() {
    MusicPlayerScreen()
}