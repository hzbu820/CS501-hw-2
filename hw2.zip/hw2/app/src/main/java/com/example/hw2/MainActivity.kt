package com.example.hw2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import com.example.hw2.ui.theme.Hw2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Hw2Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    RecipeScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun RecipeScreen(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.background(Color.White)) {
            // Title Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.LightGray)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Classic Pancakes", fontSize = 24.sp)
            }
            Divider()

            // Recipe Image (Ensure R.drawable.pancake_image exists in your drawable folder)
            Image(
                painter = painterResource(id = R.drawable.pancake_image),
                contentDescription = "Classic Pancakes",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )
            Divider()

            // Ingredients and Cooking Instructions
            Row(modifier = Modifier.padding(16.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Ingredients", fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "- 1 cup all-purpose flour")
                    Text(text = "- 2 tablespoons sugar")
                    Text(text = "- 2 teaspoons baking powder")
                    Text(text = "- 1/2 teaspoon salt")
                    Text(text = "- 1 cup milk")
                    Text(text = "- 1 egg")
                    Text(text = "- 2 tablespoons melted butter")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Instructions", fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "1. In a bowl, mix flour, sugar, baking powder, and salt.")
                    Text(text = "2. In another bowl, whisk together milk, egg, and melted butter.")
                    Text(text = "3. Combine the wet and dry ingredients until just mixed.")
                    Text(text = "4. Heat a lightly oiled griddle over medium heat.")
                    Text(text = "5. Pour about 1/4 cup batter for each pancake onto the griddle.")
                    Text(text = "6. Cook until bubbles form and edges are set, then flip and brown the other side.")
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun RecipeScreenPreview() {
    Hw2Theme {
        RecipeScreen()
    }
}
